import axios from "axios";

export const FETCH_LOGIN = "FETCH_LOGIN";

export function fetchLogin(userId, userPassword) {
  // Action: 신고하기 버튼을 클릭했을 때
  const request = axios.post("/api/v1/login/", {
    userId: userId,
    userPassword: userPassword
  });

  return {
    type: FETCH_LOGIN,
    payload: request
  };
}
