import { FETCH_LOGIN } from "../actions/index";

const initialState = {
  userName: false,
  token: false
};

export default function(state = initialState, action) {
  switch (action.type) {
    case FETCH_LOGIN:
      return {
        ...state,
        token: action.payload.token,
        userName: action.payload.userName
      };

    default:
      return state;
  }
}
